// postcss.config.js
export default {
  // Tailwind CSS v4 moved the PostCSS plugin to @tailwindcss/postcss
  plugins: {
    "@tailwindcss/postcss": {},
    autoprefixer: {},
  },
};
