import React from "react";
import Layout from "../components/Layout";

const Overview = () => {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Overview</h1>
          <p className="text-sm text-gray-500 mt-1">
            Complete business overview and analytics
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              Total Revenue
            </h3>
            <p className="text-3xl font-bold text-gray-900">₹0.00</p>
            <p className="text-xs text-green-600 mt-2">↑ 0% from last month</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              Total Orders
            </h3>
            <p className="text-3xl font-bold text-gray-900">0</p>
            <p className="text-xs text-green-600 mt-2">↑ 0% from last month</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              Active Products
            </h3>
            <p className="text-3xl font-bold text-gray-900">0</p>
            <p className="text-xs text-gray-500 mt-2">No change</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              Customers
            </h3>
            <p className="text-3xl font-bold text-gray-900">0</p>
            <p className="text-xs text-blue-600 mt-2">↑ 0 new</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Recent Activity
          </h2>
          <p className="text-gray-500 text-center py-8">
            No recent activity to display
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Overview;
