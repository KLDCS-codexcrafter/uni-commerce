import React from "react";
import Layout from "../components/Layout";

const ShippingProviders = () => {
  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Shipping Providers
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              Manage shipping carriers and provider integrations
            </p>
          </div>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            Add Provider
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              Total Providers
            </h3>
            <p className="text-3xl font-bold text-gray-900">0</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">Active</h3>
            <p className="text-3xl font-bold text-green-600">0</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              Shipments Today
            </h3>
            <p className="text-3xl font-bold text-blue-600">0</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              Total Cost
            </h3>
            <p className="text-3xl font-bold text-purple-600">₹0</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              Provider List
            </h2>
            <div className="flex gap-2">
              <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option>All Status</option>
                <option>Active</option>
                <option>Inactive</option>
              </select>
              <input
                type="search"
                placeholder="Search providers..."
                className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Provider Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Service Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Shipments
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Avg Rate
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td
                    colSpan="6"
                    className="px-6 py-8 text-center text-gray-500"
                  >
                    No shipping providers configured yet
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Popular Providers
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="border border-gray-200 rounded-lg p-4 text-center hover:border-blue-500 cursor-pointer transition-colors">
              <p className="font-semibold text-gray-900">Blue Dart</p>
              <p className="text-xs text-gray-500 mt-1">Express Delivery</p>
            </div>
            <div className="border border-gray-200 rounded-lg p-4 text-center hover:border-blue-500 cursor-pointer transition-colors">
              <p className="font-semibold text-gray-900">Delhivery</p>
              <p className="text-xs text-gray-500 mt-1">Standard & Express</p>
            </div>
            <div className="border border-gray-200 rounded-lg p-4 text-center hover:border-blue-500 cursor-pointer transition-colors">
              <p className="font-semibold text-gray-900">FedEx</p>
              <p className="text-xs text-gray-500 mt-1">International</p>
            </div>
            <div className="border border-gray-200 rounded-lg p-4 text-center hover:border-blue-500 cursor-pointer transition-colors">
              <p className="font-semibold text-gray-900">Custom</p>
              <p className="text-xs text-gray-500 mt-1">API Integration</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ShippingProviders;
