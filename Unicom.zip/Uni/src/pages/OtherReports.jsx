import React from "react";
import Layout from "../components/Layout";

const OtherReports = () => {
  const reportCategories = [
    {
      title: "Sales Reports",
      reports: [
        {
          name: "Sales Summary",
          description: "Overview of all sales activities",
        },
        {
          name: "Sales by Channel",
          description: "Channel-wise sales breakdown",
        },
        {
          name: "Sales by Product",
          description: "Product performance analysis",
        },
        { name: "Sales Trends", description: "Historical sales patterns" },
      ],
    },
    {
      title: "Inventory Reports",
      reports: [
        { name: "Stock Levels", description: "Current inventory status" },
        {
          name: "Low Stock Alert",
          description: "Products running low on stock",
        },
        { name: "Inventory Valuation", description: "Total inventory worth" },
        { name: "Dead Stock", description: "Non-moving inventory items" },
      ],
    },
    {
      title: "Financial Reports",
      reports: [
        { name: "Revenue Report", description: "Total revenue breakdown" },
        { name: "Profit & Loss", description: "P&L statement" },
        { name: "Tax Reports", description: "Tax calculations and summaries" },
        { name: "Payment Reports", description: "Payment transactions" },
      ],
    },
    {
      title: "Customer Reports",
      reports: [
        {
          name: "Customer Analytics",
          description: "Customer behavior insights",
        },
        { name: "Customer Lifetime Value", description: "CLV analysis" },
        { name: "Customer Acquisition", description: "New customer trends" },
        { name: "Customer Retention", description: "Retention metrics" },
      ],
    },
  ];

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Other Reports</h1>
            <p className="text-sm text-gray-500 mt-1">
              Access various business reports and analytics
            </p>
          </div>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            Custom Report Builder
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {reportCategories.map((category) => (
            <div
              key={category.title}
              className="bg-white rounded-xl shadow-sm border border-gray-100 p-6"
            >
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                {category.title}
              </h2>
              <div className="space-y-3">
                {category.reports.map((report) => (
                  <div
                    key={report.name}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all cursor-pointer group"
                  >
                    <div className="flex-1">
                      <h3 className="text-sm font-medium text-gray-900 group-hover:text-blue-600">
                        {report.name}
                      </h3>
                      <p className="text-xs text-gray-500 mt-1">
                        {report.description}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                        <svg
                          className="w-5 h-5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                          />
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                          />
                        </svg>
                      </button>
                      <button className="p-2 text-gray-400 hover:text-green-600 transition-colors">
                        <svg
                          className="w-5 h-5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200 p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-blue-600 rounded-lg">
              <svg
                className="w-6 h-6 text-white"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                />
              </svg>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Need a Custom Report?
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Create custom reports tailored to your specific business needs
                with our advanced report builder.
              </p>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                Launch Report Builder
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default OtherReports;
