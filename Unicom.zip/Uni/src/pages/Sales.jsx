import React from "react";
import Layout from "../components/Layout";

const Sales = () => {
  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sales</h1>
          <p className="text-sm text-gray-500 mt-1">
            Track and manage your sales performance
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              Today's Sales
            </h3>
            <p className="text-3xl font-bold text-gray-900">₹0.00</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              This Week
            </h3>
            <p className="text-3xl font-bold text-gray-900">₹0.00</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-sm font-medium text-gray-600 mb-2">
              This Month
            </h3>
            <p className="text-3xl font-bold text-gray-900">₹0.00</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Sales Chart
          </h2>
          <div className="h-64 flex items-center justify-center border-2 border-dashed border-gray-200 rounded-lg">
            <p className="text-gray-400">Sales chart will be displayed here</p>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Sales;
