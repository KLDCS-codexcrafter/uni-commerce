// import React from "react";
// import Layout from "../components/Layout";
// import "../App.css";

// function StatCard({ title, value, sub }) {
//   return (
//     <div className="bg-white rounded-lg border border-gray-200 p-4 shadow-sm hover:shadow-md transition-shadow">
//       <div className="text-xs uppercase tracking-wide text-gray-500 font-semibold mb-1">
//         {title}
//       </div>
//       <div className="text-2xl font-semibold text-gray-800">{value}</div>
//       {sub && <div className="text-xs text-gray-400 mt-1">{sub}</div>}
//     </div>
//   );
// }

// function Dashboard() {
//   return (
//     <Layout>
//       <div className="grid gap-6 md:grid-cols-3">
//         <StatCard
//           title="Today's Revenue"
//           value="₹0.00"
//           sub="Yesterday: ₹0.00"
//         />
//         <StatCard title="Today's Order Items" value="0" sub="Yesterday: 0" />
//         <StatCard
//           title="Pending Retail Orders"
//           value="0"
//           sub="Verification Pending"
//         />
//       </div>
//       <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
//         <StatCard title="Pending Orders" value="0" />
//         <StatCard title="Unfulfillable Items" value="0" />
//         <StatCard title="Verified Orders" value="0" />
//         <StatCard title="Allocated Orders" value="0" />
//         <StatCard title="To be Packed" value="0" />
//         <StatCard title="Label Generated" value="0" />
//       </div>
//     </Layout>
//   );
// }

// export default Dashboard;

import React from "react";
import Layout from "../components/Layout";

const Dashboard = () => {
  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-sm text-gray-500 mt-1">
              Last updated:{" "}
              {new Date().toLocaleString("en-US", {
                month: "short",
                day: "numeric",
                hour: "numeric",
                minute: "numeric",
              })}
            </p>
          </div>
        </div>

        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Today's Revenue"
            value="₹0.00"
            subtitle="Yesterday: ₹0.00"
            icon={<RevenueIcon />}
            color="blue"
          />
          <MetricCard
            title="Order Items"
            value="0"
            subtitle="Yesterday: 0"
            icon={<OrderIcon />}
            color="green"
          />
          <MetricCard
            title="Pending Orders"
            value="0"
            subtitle="Verification pending"
            icon={<PendingIcon />}
            color="yellow"
          />
          <MetricCard
            title="Alerts"
            value="0"
            subtitle="Active issues"
            icon={<AlertIcon />}
            color="red"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Left Column - Takes 2 columns on XL screens */}
          <div className="xl:col-span-2 space-y-6">
            {/* Order Status Overview */}
            <DashboardCard title="Order Status Overview">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <StatusItem label="Pending Orders" value="0" color="yellow" />
                <StatusItem label="Unfulfillable Items" value="0" color="red" />
                <StatusItem label="Verified Orders" value="0" color="green" />
                <StatusItem label="Allocated Orders" value="0" color="blue" />
                <StatusItem label="To be Packed" value="0" color="purple" />
                <StatusItem label="Label Generated" value="0" color="indigo" />
              </div>
            </DashboardCard>

            {/* Shipment Tracking */}
            <DashboardCard title="Shipment Tracking">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                        Status
                      </th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                        Count
                      </th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    <ShipmentRow label="Allocated Orders" value="0" />
                    <ShipmentRow label="Pick Released" value="0" />
                    <ShipmentRow label="Pending Invoice/Label" value="0" />
                    <ShipmentRow label="Ready To Ship" value="0" />
                    <ShipmentRow label="Manifested" value="0" />
                    <ShipmentRow label="Dispatched" value="0" />
                  </tbody>
                </table>
              </div>
            </DashboardCard>

            {/* Product & Channel Alerts */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <DashboardCard title="Product Alerts" size="small">
                <div className="space-y-3">
                  <AlertItem
                    label="Failed Inventory"
                    value="0"
                    severity="error"
                  />
                  <AlertItem
                    label="Disabled Inventory"
                    value="0"
                    severity="warning"
                  />
                  <AlertItem
                    label="Failed Price Sync"
                    value="0"
                    severity="error"
                  />
                </div>
              </DashboardCard>

              <DashboardCard title="Channel Alerts" size="small">
                <div className="space-y-3">
                  <AlertItem label="Connectors" value="0" severity="info" />
                  <AlertItem
                    label="Pending Configuration"
                    value="0"
                    severity="warning"
                  />
                </div>
              </DashboardCard>
            </div>
          </div>

          {/* Right Column - Takes 1 column on XL screens */}
          <div className="space-y-6">
            {/* Retail Order Alerts */}
            <DashboardCard title="Retail Order Alerts" compact>
              <div className="space-y-2">
                <AlertItem label="Pending Orders" value="0" />
                <AlertItem label="SLA Breached" value="0" />
                <AlertItem label="Near SLA Breach" value="0" />
                <AlertItem label="Shipment Errors" value="0" />
                <AlertItem label="Failed Notifications" value="0" />
              </div>
            </DashboardCard>

            {/* Business Order Alerts */}
            <DashboardCard title="Business Order Alerts" compact>
              <div className="space-y-2">
                <AlertItem label="Pending Orders" value="0" />
                <AlertItem label="Unfulfillable Items" value="0" />
                <AlertItem label="Unverified Orders" value="0" />
                <AlertItem label="Unallocated Orders" value="0" />
                <AlertItem label="Allocated Orders" value="0" />
              </div>
            </DashboardCard>

            {/* Pending Retail Orders */}
            <DashboardCard title="Pending Retail Orders" compact>
              <div className="mb-4">
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                  <option>All Channels</option>
                  <option>Amazon</option>
                  <option>Flipkart</option>
                  <option>Website</option>
                </select>
              </div>
              <div className="space-y-2">
                <AlertItem label="Pending Verification" value="0" />
                <AlertItem label="Yet to be Packed" value="0" />
                <AlertItem label="Label Generated" value="0" />
              </div>
            </DashboardCard>
          </div>
        </div>
      </div>
    </Layout>
  );
};

// Metric Card Component
const MetricCard = ({ title, value, subtitle, icon, color = "blue" }) => {
  const colorClasses = {
    blue: "bg-blue-50 text-blue-600",
    green: "bg-green-50 text-green-600",
    yellow: "bg-yellow-50 text-yellow-600",
    red: "bg-red-50 text-red-600",
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mb-1">{value}</p>
          <p className="text-xs text-gray-500">{subtitle}</p>
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>{icon}</div>
      </div>
    </div>
  );
};

// Dashboard Card Component
const DashboardCard = ({
  title,
  children,
  size = "normal",
  compact = false,
}) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
      <div
        className={`border-b border-gray-100 ${
          compact ? "px-5 py-3" : "px-6 py-4"
        }`}
      >
        <h2
          className={`font-semibold text-gray-900 ${
            compact ? "text-base" : "text-lg"
          }`}
        >
          {title}
        </h2>
      </div>
      <div className={compact ? "p-5" : "p-6"}>{children}</div>
    </div>
  );
};

// Status Item Component
const StatusItem = ({ label, value, color = "gray" }) => {
  const colorClasses = {
    yellow: "bg-yellow-50 text-yellow-700 border-yellow-200",
    red: "bg-red-50 text-red-700 border-red-200",
    green: "bg-green-50 text-green-700 border-green-200",
    blue: "bg-blue-50 text-blue-700 border-blue-200",
    purple: "bg-purple-50 text-purple-700 border-purple-200",
    indigo: "bg-indigo-50 text-indigo-700 border-indigo-200",
    gray: "bg-gray-50 text-gray-700 border-gray-200",
  };

  return (
    <div className={`rounded-lg border p-4 ${colorClasses[color]}`}>
      <p className="text-xs font-medium mb-1 opacity-75">{label}</p>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
};

// Shipment Row Component
const ShipmentRow = ({ label, value }) => {
  return (
    <tr className="hover:bg-gray-50 transition-colors">
      <td className="py-3 px-4 text-sm text-gray-700">{label}</td>
      <td className="py-3 px-4">
        <span className="inline-flex items-center justify-center min-w-[2rem] px-2 py-1 text-sm font-semibold text-gray-900 bg-gray-100 rounded-md">
          {value}
        </span>
      </td>
      <td className="py-3 px-4">
        <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
          View →
        </button>
      </td>
    </tr>
  );
};

// Alert Item Component
const AlertItem = ({ label, value, severity = "default" }) => {
  const severityColors = {
    error: "text-red-600 bg-red-50",
    warning: "text-yellow-600 bg-yellow-50",
    info: "text-blue-600 bg-blue-50",
    default: "text-gray-900 bg-gray-100",
  };

  return (
    <div className="flex justify-between items-center py-2.5 border-b border-gray-100 last:border-b-0 hover:bg-gray-50 px-2 -mx-2 rounded transition-colors">
      <span className="text-sm text-gray-700">{label}</span>
      <span
        className={`inline-flex items-center justify-center min-w-[2.5rem] px-2.5 py-1 text-sm font-semibold rounded-md ${severityColors[severity]}`}
      >
        {value}
      </span>
    </div>
  );
};

// Icon Components
const RevenueIcon = () => (
  <svg
    className="w-6 h-6"
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
);

const OrderIcon = () => (
  <svg
    className="w-6 h-6"
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
    />
  </svg>
);

const PendingIcon = () => (
  <svg
    className="w-6 h-6"
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
);

const AlertIcon = () => (
  <svg
    className="w-6 h-6"
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
    />
  </svg>
);

export default Dashboard;
