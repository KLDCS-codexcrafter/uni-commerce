import React, { useState } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";

function Layout({ children }) {
  const [isSettingsMode, setIsSettingsMode] = useState(false);

  const handleSettingsClick = () => {
    setIsSettingsMode(true);
  };

  const handleModeChange = (settingsMode) => {
    setIsSettingsMode(settingsMode);
  };

  return (
    <div className="h-screen bg-gray-100 font-sans">
      {/* Fixed Header */}
      <div className="fixed top-0 left-0 right-0 z-30">
        <Header onSettingsClick={handleSettingsClick} />
      </div>

      {/* Fixed Sidebar */}
      <div className="fixed top-14 left-0 bottom-0 z-20">
        <Sidebar
          isSettingsMode={isSettingsMode}
          onModeChange={handleModeChange}
        />
      </div>

      {/* Main Content Area - scrollable */}
      <div className="ml-14 mt-14 h-[calc(100vh-3.5rem)] overflow-y-auto">
        <main className="p-6 space-y-6">{children}</main>
      </div>
    </div>
  );
}

export default Layout;
