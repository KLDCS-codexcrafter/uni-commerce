import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

// Menu config with hover flyout contents
const menu = [
  {
    key: "dashBoard",
    label: "Dashboard",

    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <rect x="3" y="3" width="7" height="9" rx="1" />
        <rect x="14" y="3" width="7" height="5" rx="1" />
        <rect x="14" y="12" width="7" height="9" rx="1" />
        <rect x="3" y="16" width="7" height="5" rx="1" />
      </svg>
    ),
    groups: [
      {
        title: "DASHBOARD",
        links: [
          { name: "Overview", href: "/overview" },
          { name: "Sales", href: "/sales" },
          { name: "Fulfillment", href: "/fulfillment" },
          { name: "Returns", href: "/returns" },
          { name: "Inventory", href: "/inventory" },
          { name: "Payments", href: "/payments" },
        ],
      },
      {
        title: "REPORTS",
        links: [
          { name: "Order Items", href: "/order-items" },
          { name: "Invoices", href: "/invoices" },
          { name: "Other Reports", href: "/other-reports" },
        ],
      },
    ],
  },
  {
    key: "order",
    label: "Order",

    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <path d="M6 2L3 6v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6l-3-4H6z" />
        <line x1="3" y1="6" x2="21" y2="6" />
        <path d="M16 10a4 4 0 01-8 0" />
      </svg>
    ),
    groups: [
      {
        title: "SALE ORDERS",
        links: [
          { name: "Orders", href: "/orders" },
          { name: "B2B Orders", href: "/b2b-orders" },
        ],
      },
      {
        title: "CUSTOMERS",
        links: [
          { name: "Customers", href: "/customers" },
          {
            name: "Customer Discount Groups",
            href: "/customer-discount-groups",
          },
          {
            name: "Dispatch Tolerance Groups",
            href: "/dispatch-tolerance-groups",
          },
        ],
      },
    ],
  },
  {
    key: "fulfillment",
    label: "Fulfillment",

    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <rect x="1" y="3" width="15" height="13" rx="2" />
        <path d="M16 8h4l3 3v5H16V8z" />
        <circle cx="5.5" cy="18.5" r="2.5" />
        <circle cx="18.5" cy="18.5" r="2.5" />
      </svg>
    ),
    groups: [
      {
        title: "DISPATCH",
        links: [
          { name: "Shipments", href: "/shipments" },
          { name: "Pack Group", href: "/pack-group" },
          { name: "Dispatch Group", href: "/dispatch-group" },
          { name: "Picklists", href: "/picklists" },
          { name: "Manifests", href: "/manifests" },
        ],
      },
      {
        title: "STAGING",
        links: [{ name: "Shelf View", href: "/shelf-view" }],
      },
    ],
  },
  {
    key: "search-asn",
    label: "Search ASN",
    to: "/search-asn",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <circle cx="11" cy="11" r="8" />
        <path d="M21 21l-4.35-4.35" />
        <rect x="7" y="9" width="1" height="4" />
        <rect x="9" y="9" width="1" height="4" />
        <rect x="11" y="9" width="2" height="4" />
        <rect x="14" y="9" width="1" height="4" />
      </svg>
    ),
    isClickable: true,
  },
  {
    key: "inbound",
    label: "Inbound",
    to: "/inbound",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <path d="M19 14l-7 7-7-7" />
        <path d="M12 21V3" />
        <rect x="3" y="3" width="5" height="5" rx="1" />
        <rect x="16" y="3" width="5" height="5" rx="1" />
      </svg>
    ),
    groups: [
      {
        title: "PUTAWAY",
        links: [
          { name: "Putaway", href: "/putaway" },
          { name: "Awaiting Putaway", href: "/awaiting-putaway" },
        ],
      },
    ],
  },
  {
    key: "manifests",
    label: "Manifests",
    to: "/manifests",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <polyline points="14,2 14,8 20,8" />
        <line x1="16" y1="13" x2="8" y2="13" />
        <line x1="16" y1="17" x2="8" y2="17" />
        <polyline points="10,9 9,9 8,9" />
      </svg>
    ),
    isClickable: true,
  },
];

// Settings menu config
const settingsMenu = [
  {
    key: "products",
    label: "Products",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" />
        <line x1="7" y1="7" x2="7.01" y2="7" />
      </svg>
    ),
    groups: [
      {
        title: "PRODUCTS",
        links: [
          { name: "Listings", href: "/listings" },
          { name: "Products", href: "/products" },
          { name: "RollupSku", href: "/rollupsku" },
          { name: "Categories", href: "/categories" },
          { name: "Kit", href: "/kit" },
        ],
      },
      {
        title: "INVENTORY",
        links: [
          { name: "Inventory", href: "/inventory" },
          { name: "Channel Inventory", href: "/channel-inventory" },
          { name: "Inventory Snapshot", href: "/inventory-snapshot" },
          { name: "Inventory Ledger", href: "/inventory-ledger" },
        ],
      },
      {
        title: "CONFIGURATION",
        links: [
          { name: "Tax Classes", href: "/tax-classes" },
          { name: "Discount Group Items", href: "/discount-group-items" },
        ],
      },
    ],
  },
  {
    key: "tools",
    label: "Tools",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z" />
      </svg>
    ),
    groups: [
      {
        title: "DATA I/O",
        links: [
          { name: "Subscriptions", href: "/subscriptions" },
          { name: "Import", href: "/import" },
        ],
      },
      {
        title: "UNI CAPTURE",
        links: [
          { name: "Record Video", href: "/record-video" },
          { name: "Access Recording", href: "/access-recording" },
          { name: "My Folders", href: "/my-folders" },
        ],
      },
    ],
  },
  {
    key: "settings",
    label: "Settings",
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="w-6 h-6"
      >
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
      </svg>
    ),
    groups: [
      {
        title: "CHANNELS",
        links: [
          { name: "Channels", href: "/channels" },
          {
            name: "Channel Return Facility Mapping",
            href: "/channel-return-facility-mapping",
          },
        ],
      },
      {
        title: "FACILITIES",
        links: [
          { name: "Facilities", href: "/facilities" },
          { name: "Billing Parties", href: "/billing-parties" },
          { name: "Business Lines", href: "/business-lines" },
        ],
      },
      {
        title: "OTHER",
        links: [
          { name: "Templates", href: "/templates" },
          { name: "Pick Buckets", href: "/pick-buckets" },
        ],
      },
      {
        title: "USERS",
        links: [{ name: "Users", href: "/users" }],
      },
      {
        title: "SHIPPING PROVIDERS",
        links: [
          { name: "Shipping Providers", href: "/shipping-providers" },
          { name: "Serviceability", href: "/serviceability" },
        ],
      },
      {
        title: "STOCK ALLOCATION",
        links: [
          {
            name: "Dispatch Tolerance Groups",
            href: "/dispatch-tolerance-groups",
          },
        ],
      },
      {
        title: "LAYOUTS",
        links: [
          {
            name: "Package Types",
            href: "/package-types",
          },
        ],
      },
    ],
  },
];

function HoverPanel({ title, groups, to, isClickable, isSettings }) {
  if (isClickable) {
    return (
      <>
        {/* Bridge area to prevent hover loss */}
        <div className="invisible group-hover:visible absolute left-full top-0 w-3 h-full z-40"></div>
        <div className="invisible opacity-0 translate-x-1 group-hover:visible group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-150 pointer-events-none group-hover:pointer-events-auto absolute left-full top-0 ml-3 w-48 bg-gray-900 text-gray-100 rounded-md shadow-2xl border border-gray-800 p-4 z-50">
          <Link
            to={to}
            className="text-sm font-semibold text-gray-200 hover:text-white hover:underline cursor-pointer flex items-center justify-between"
          >
            <span>{title}</span>
            <svg
              viewBox="0 0 24 24"
              className="w-4 h-4 text-gray-500"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M9 18l6-6-6-6" />
            </svg>
          </Link>
        </div>
      </>
    );
  }

  return (
    <>
      {/* Bridge area to prevent hover loss */}
      <div className="invisible group-hover:visible absolute left-full top-0 w-3 h-full z-40"></div>
      <div
        className={`invisible opacity-0 translate-x-1 group-hover:visible group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-150 pointer-events-none group-hover:pointer-events-auto absolute left-full ml-3 w-96 bg-gray-900 text-gray-100 rounded-md shadow-2xl border border-gray-800 p-5 z-50 overflow-y-auto ${
          isSettings ? "top-1/2 -translate-y-1/2" : "top-0"
        }`}
        style={{
          maxHeight: "calc(100vh - 6rem)",
        }}
      >
        <div className="text-sm font-semibold text-gray-200 mb-3">{title}</div>
        <div className="grid grid-cols-2 gap-6">
          {groups?.map((g) => (
            <div key={g.title}>
              <div className="text-[11px] uppercase tracking-wider text-gray-400 mb-2">
                {g.title}
              </div>
              <ul className="space-y-2">
                {g.links.map((l) => (
                  <li key={l.name}>
                    <Link
                      to={l.href}
                      className="flex items-center justify-between text-sm text-gray-200 hover:text-white hover:underline"
                    >
                      <span>{l.name}</span>
                      <svg
                        viewBox="0 0 24 24"
                        className="w-4 h-4 text-gray-500"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path d="M9 18l6-6-6-6" />
                      </svg>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function Sidebar({ isSettingsMode, onModeChange }) {
  const [currentMenu, setCurrentMenu] = useState(menu);
  const location = useLocation();

  // Check if current path belongs to settings menu
  const isSettingsPath = (pathname) => {
    return settingsMenu.some((menuItem) =>
      menuItem.groups?.some((group) =>
        group.links.some((link) => link.href === pathname)
      )
    );
  };

  // Auto-switch to settings mode if on a settings page
  useEffect(() => {
    if (isSettingsPath(location.pathname) && !isSettingsMode) {
      onModeChange(true);
    }
  }, [location.pathname]);

  useEffect(() => {
    setCurrentMenu(isSettingsMode ? settingsMenu : menu);
  }, [isSettingsMode]);

  return (
    <aside className="h-full w-14 bg-gray-900 text-gray-200 flex flex-col items-center py-4 space-y-6 shadow-lg relative">
      <div className="text-xl font-bold tracking-wide text-blue-400">U</div>

      {isSettingsMode && (
        <button
          onClick={() => onModeChange(false)}
          className="w-10 h-10 flex items-center justify-center rounded-md hover:bg-gray-800 transition-colors"
          title="Back to Main Menu"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="w-6 h-6"
          >
            <path d="M19 12H5" />
            <path d="M12 19l-7-7 7-7" />
          </svg>
        </button>
      )}

      <nav className="flex flex-col space-y-4 w-full items-center">
        {currentMenu.map((item) => (
          <div key={item.key} className="group relative">
            <button
              aria-label={item.label}
              className="w-10 h-10 flex items-center justify-center rounded-md hover:bg-gray-800 transition-colors"
            >
              {item.icon}
            </button>
            {/* Small text label for quick glance */}
            <span className="pointer-events-none absolute left-full top-1/2 -translate-y-1/2 ml-2 rounded bg-black/80 px-2 py-1 text-xs opacity-0 translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all">
              {item.label}
            </span>
            {/* Large flyout content */}
            {(item.groups || item.isClickable) && (
              <HoverPanel
                title={item.label}
                groups={item.groups}
                to={item.to}
                isClickable={item.isClickable}
                isSettings={isSettingsMode}
              />
            )}
          </div>
        ))}
      </nav>
      {/* <div className="mt-auto flex flex-col space-y-3">
        <div className="group relative">
          <button className="w-10 h-10 flex items-center justify-center rounded-md hover:bg-gray-800">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="w-6 h-6"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M12 8v4l3 3" />
            </svg>
          </button>
          <span className="pointer-events-none absolute left-full top-1/2 -translate-y-1/2 ml-2 rounded bg-black/80 px-2 py-1 text-xs opacity-0 translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all">
            Activity
          </span>
        </div>
        <div className="group relative">
          <button className="w-10 h-10 flex items-center justify-center rounded-md hover:bg-gray-800">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="w-6 h-6"
            >
              <path d="M4 4h16v16H4z" />
            </svg>
          </button>
          <span className="pointer-events-none absolute left-full top-1/2 -translate-y-1/2 ml-2 rounded bg-black/80 px-2 py-1 text-xs opacity-0 translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all">
            Files
          </span>
        </div>
      </div> */}
    </aside>
  );
}

export default Sidebar;
