import React, { useState } from "react";
import Image from "../assets/react.svg";

function Header({ onSettingsClick }) {
  return (
    <header className="h-14 bg-white border-b border-gray-200 flex items-center px-4 justify-between sticky top-0 z-10">
      <div className="flex items-center space-x-3">
        <div className="text-xl font-semibold text-gray-800 tracking-tight">
          Unicom Dashboard
        </div>
        <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full border border-blue-200">
          v1.0
        </span>
      </div>
      <div className="flex-1 max-w-xl mx-6">
        <div className="relative">
          <input
            type="text"
            placeholder="Search orders, SKUs, payments..."
            className="w-full pl-10 pr-3 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm bg-gray-50"
          />
          <svg
            className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"
            viewBox="0 0 24 24"
            stroke="currentColor"
            fill="none"
            strokeWidth="2"
          >
            <circle cx="11" cy="11" r="7" />
            <path d="M21 21l-4.35-4.35" />
          </svg>
        </div>
      </div>
      <div className="flex items-center space-x-1">
        <button className="relative p-2 rounded-md hover:bg-gray-100">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="w-6 h-6 text-gray-600"
          >
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          </svg>
          <span className="sr-only">Alerts</span>
        </button>

        <button
          className="relative p-2 rounded-md hover:bg-gray-100"
          title="Settings"
          onClick={onSettingsClick}
        >
          <img src={Image} alt="Settings" className="w-6 h-6 text-gray-600" />
          <span className="sr-only">Settings</span>
        </button>

        <div className="flex items-center space-x-1">
          <img
            src="https://ui-avatars.com/api/?name=User&background=0D8ABC&color=fff"
            alt="User avatar"
            className="w-9 h-9 rounded-md shadow-sm"
          />
          <div className="leading-tight">
            <div className="text-sm font-medium text-gray-700">s4foryou</div>
            <div className="text-[11px] text-gray-400">Administrator</div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
