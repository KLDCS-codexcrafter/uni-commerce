import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./App.css";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Overview from "./pages/Overview";
import Sales from "./pages/Sales";
import Fulfillment from "./pages/Fulfillment";
import Returns from "./pages/Returns";
import Inventory from "./pages/Inventory";
import Payments from "./pages/Payments";
import Orders from "./pages/Orders";
import Customers from "./pages/Customers";
import Shipments from "./pages/Shipments";
import Products from "./pages/Products";
import OrderItems from "./pages/OrderItems";
import Invoices from "./pages/Invoices";
import OtherReports from "./pages/OtherReports";
import B2BOrders from "./pages/B2BOrders";
import CustomerDiscountGroups from "./pages/CustomerDiscountGroups";
import DispatchToleranceGroups from "./pages/DispatchToleranceGroups";
import PackGroup from "./pages/PackGroup";
import DispatchGroup from "./pages/DispatchGroup";
import Picklists from "./pages/Picklists";
import Manifests from "./pages/Manifests";
import ShelfView from "./pages/ShelfView";
import Putaway from "./pages/Putaway";
import AwaitingPutaway from "./pages/AwaitingPutaway";
import SearchASN from "./pages/SearchASN";
import Listings from "./pages/Listings";
import RollupSku from "./pages/RollupSku";
import Categories from "./pages/Categories";
import Kit from "./pages/Kit";
import ChannelInventory from "./pages/ChannelInventory";
import InventorySnapshot from "./pages/InventorySnapshot";
import InventoryLedger from "./pages/InventoryLedger";
import TaxClasses from "./pages/TaxClasses";
import DiscountGroupItems from "./pages/DiscountGroupItems";
import Subscriptions from "./pages/Subscriptions";
import Import from "./pages/Import";
import RecordVideo from "./pages/RecordVideo";
import AccessRecording from "./pages/AccessRecording";
import MyFolders from "./pages/MyFolders";
import Channels from "./pages/Channels";
import ChannelReturnFacilityMapping from "./pages/ChannelReturnFacilityMapping";
import Facilities from "./pages/Facilities";
import BillingParties from "./pages/BillingParties";
import BusinessLines from "./pages/BusinessLines";
import Templates from "./pages/Templates";
import PickBuckets from "./pages/PickBuckets";
import Users from "./pages/Users";
import ShippingProviders from "./pages/ShippingProviders";
import Serviceability from "./pages/Serviceability";
import PackageTypes from "./pages/PackageTypes";

// Protected Route Component
function ProtectedRoute({ children }) {
  const isAuthenticated = localStorage.getItem("isAuthenticated") === "true";
  return isAuthenticated ? children : <Navigate to="/login" replace />;
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/overview"
          element={
            <ProtectedRoute>
              <Overview />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales"
          element={
            <ProtectedRoute>
              <Sales />
            </ProtectedRoute>
          }
        />
        <Route
          path="/fulfillment"
          element={
            <ProtectedRoute>
              <Fulfillment />
            </ProtectedRoute>
          }
        />
        <Route
          path="/returns"
          element={
            <ProtectedRoute>
              <Returns />
            </ProtectedRoute>
          }
        />
        <Route
          path="/inventory"
          element={
            <ProtectedRoute>
              <Inventory />
            </ProtectedRoute>
          }
        />
        <Route
          path="/payments"
          element={
            <ProtectedRoute>
              <Payments />
            </ProtectedRoute>
          }
        />
        <Route
          path="/orders"
          element={
            <ProtectedRoute>
              <Orders />
            </ProtectedRoute>
          }
        />
        <Route
          path="/customers"
          element={
            <ProtectedRoute>
              <Customers />
            </ProtectedRoute>
          }
        />
        <Route
          path="/shipments"
          element={
            <ProtectedRoute>
              <Shipments />
            </ProtectedRoute>
          }
        />
        <Route
          path="/products"
          element={
            <ProtectedRoute>
              <Products />
            </ProtectedRoute>
          }
        />
        <Route
          path="/order-items"
          element={
            <ProtectedRoute>
              <OrderItems />
            </ProtectedRoute>
          }
        />
        <Route
          path="/invoices"
          element={
            <ProtectedRoute>
              <Invoices />
            </ProtectedRoute>
          }
        />
        <Route
          path="/other-reports"
          element={
            <ProtectedRoute>
              <OtherReports />
            </ProtectedRoute>
          }
        />
        <Route
          path="/b2b-orders"
          element={
            <ProtectedRoute>
              <B2BOrders />
            </ProtectedRoute>
          }
        />
        <Route
          path="/customer-discount-groups"
          element={
            <ProtectedRoute>
              <CustomerDiscountGroups />
            </ProtectedRoute>
          }
        />
        <Route
          path="/dispatch-tolerance-groups"
          element={
            <ProtectedRoute>
              <DispatchToleranceGroups />
            </ProtectedRoute>
          }
        />
        <Route
          path="/pack-group"
          element={
            <ProtectedRoute>
              <PackGroup />
            </ProtectedRoute>
          }
        />
        <Route
          path="/dispatch-group"
          element={
            <ProtectedRoute>
              <DispatchGroup />
            </ProtectedRoute>
          }
        />
        <Route
          path="/picklists"
          element={
            <ProtectedRoute>
              <Picklists />
            </ProtectedRoute>
          }
        />
        <Route
          path="/manifests"
          element={
            <ProtectedRoute>
              <Manifests />
            </ProtectedRoute>
          }
        />
        <Route
          path="/shelf-view"
          element={
            <ProtectedRoute>
              <ShelfView />
            </ProtectedRoute>
          }
        />
        <Route
          path="/putaway"
          element={
            <ProtectedRoute>
              <Putaway />
            </ProtectedRoute>
          }
        />
        <Route
          path="/awaiting-putaway"
          element={
            <ProtectedRoute>
              <AwaitingPutaway />
            </ProtectedRoute>
          }
        />
        <Route
          path="/search-asn"
          element={
            <ProtectedRoute>
              <SearchASN />
            </ProtectedRoute>
          }
        />
        <Route
          path="/listings"
          element={
            <ProtectedRoute>
              <Listings />
            </ProtectedRoute>
          }
        />
        <Route
          path="/rollupsku"
          element={
            <ProtectedRoute>
              <RollupSku />
            </ProtectedRoute>
          }
        />
        <Route
          path="/categories"
          element={
            <ProtectedRoute>
              <Categories />
            </ProtectedRoute>
          }
        />
        <Route
          path="/kit"
          element={
            <ProtectedRoute>
              <Kit />
            </ProtectedRoute>
          }
        />
        <Route
          path="/channel-inventory"
          element={
            <ProtectedRoute>
              <ChannelInventory />
            </ProtectedRoute>
          }
        />
        <Route
          path="/inventory-snapshot"
          element={
            <ProtectedRoute>
              <InventorySnapshot />
            </ProtectedRoute>
          }
        />
        <Route
          path="/inventory-ledger"
          element={
            <ProtectedRoute>
              <InventoryLedger />
            </ProtectedRoute>
          }
        />
        <Route
          path="/tax-classes"
          element={
            <ProtectedRoute>
              <TaxClasses />
            </ProtectedRoute>
          }
        />
        <Route
          path="/discount-group-items"
          element={
            <ProtectedRoute>
              <DiscountGroupItems />
            </ProtectedRoute>
          }
        />
        <Route
          path="/subscriptions"
          element={
            <ProtectedRoute>
              <Subscriptions />
            </ProtectedRoute>
          }
        />
        <Route
          path="/import"
          element={
            <ProtectedRoute>
              <Import />
            </ProtectedRoute>
          }
        />
        <Route
          path="/record-video"
          element={
            <ProtectedRoute>
              <RecordVideo />
            </ProtectedRoute>
          }
        />
        <Route
          path="/access-recording"
          element={
            <ProtectedRoute>
              <AccessRecording />
            </ProtectedRoute>
          }
        />
        <Route
          path="/my-folders"
          element={
            <ProtectedRoute>
              <MyFolders />
            </ProtectedRoute>
          }
        />
        <Route
          path="/channels"
          element={
            <ProtectedRoute>
              <Channels />
            </ProtectedRoute>
          }
        />
        <Route
          path="/channel-return-facility-mapping"
          element={
            <ProtectedRoute>
              <ChannelReturnFacilityMapping />
            </ProtectedRoute>
          }
        />
        <Route
          path="/facilities"
          element={
            <ProtectedRoute>
              <Facilities />
            </ProtectedRoute>
          }
        />
        <Route
          path="/billing-parties"
          element={
            <ProtectedRoute>
              <BillingParties />
            </ProtectedRoute>
          }
        />
        <Route
          path="/business-lines"
          element={
            <ProtectedRoute>
              <BusinessLines />
            </ProtectedRoute>
          }
        />
        <Route
          path="/templates"
          element={
            <ProtectedRoute>
              <Templates />
            </ProtectedRoute>
          }
        />
        <Route
          path="/pick-buckets"
          element={
            <ProtectedRoute>
              <PickBuckets />
            </ProtectedRoute>
          }
        />
        <Route
          path="/users"
          element={
            <ProtectedRoute>
              <Users />
            </ProtectedRoute>
          }
        />
        <Route
          path="/shipping-providers"
          element={
            <ProtectedRoute>
              <ShippingProviders />
            </ProtectedRoute>
          }
        />
        <Route
          path="/serviceability"
          element={
            <ProtectedRoute>
              <Serviceability />
            </ProtectedRoute>
          }
        />
        <Route
          path="/package-types"
          element={
            <ProtectedRoute>
              <PackageTypes />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
